# Pac-Man Clone (unofficial)

A small Pac-Man-style maze game written in Python with pygame. Eat all the
dots and avoid the ghosts.

**Play it in your browser:** `https://YOUR-USERNAME.github.io/YOUR-REPO/`
(click the page once when it loads so the game gets keyboard focus)

> Unofficial fan project, not affiliated with or endorsed by Bandai Namco.
> Pac-Man is a trademark of Bandai Namco Entertainment. All code here is
> original.

## Controls

| Key            | Action  |
| -------------- | ------- |
| Arrows / WASD  | Move    |
| R              | Restart |

You can press a direction before a junction; the turn happens as soon as it
is possible.

## Run locally

```bash
pip install -r requirements.txt
python game/main.py
```

## How the web version works

The game is built for the browser with [pygbag](https://github.com/pygame-web/pygbag),
which compiles pygame to WebAssembly. A GitHub Actions workflow
(`.github/workflows/deploy.yml`) rebuilds and publishes it to GitHub Pages
every time you push to `main`.

## License

MIT, see [LICENSE](LICENSE).
