import asyncio
import pygame
import random
import math

pygame.init()

# Game settings
TILE_SIZE = 28
TOP_SPACE = 50
FPS = 60

PAC_SPEED = 2.8
GHOST_SPEED = 1.4

EPS = 1e-6

maze = [
    "#####################",
    "#.........#.........#",
    "#.###.###.#.###.###.#",
    "#o#...#...#...#...#o#",
    "#.###.#.###.###.#.###",
    "#.....#...#...#.....#",
    "#####.###.#.###.#####",
    "#.........#.........#",
    "#####.##.   .##.#####",
    "#.....#...#...#.....#",
    "#.###.#.###.###.#.###",
    "#o..#...#...#...#..o#",
    "###.#.###.#.###.#.###",
    "#.........#.........#",
    "#####################",
]

ROWS = len(maze)
COLS = len(maze[0])

WIDTH = COLS * TILE_SIZE
HEIGHT = ROWS * TILE_SIZE + TOP_SPACE

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pac-Man - Continuous Movement")

clock = pygame.time.Clock()

# Colors
BLACK = (0, 0, 0)
BLUE = (30, 60, 220)
YELLOW = (255, 230, 0)
WHITE = (255, 255, 255)
PINK = (255, 80, 160)
RED = (255, 50, 50)
CYAN = (0, 230, 230)

font = pygame.font.Font(None, 30)
big_font = pygame.font.Font(None, 48)

# Arrow keys and WASD both work.
DIRECTIONS = {
    pygame.K_RIGHT: (1, 0),
    pygame.K_LEFT: (-1, 0),
    pygame.K_UP: (0, -1),
    pygame.K_DOWN: (0, 1),
    pygame.K_d: (1, 0),
    pygame.K_a: (-1, 0),
    pygame.K_w: (0, -1),
    pygame.K_s: (0, 1),
}

# Each direction exactly once (used for ghost choices).
DIRECTION_LIST = [(1, 0), (-1, 0), (0, -1), (0, 1)]

STOP = (0, 0)


def tile_center(tile):
    return tile * TILE_SIZE + TILE_SIZE / 2


def current_tile(x, y):
    tile_x = round((x - TILE_SIZE / 2) / TILE_SIZE)
    tile_y = round((y - TILE_SIZE / 2) / TILE_SIZE)
    return tile_x, tile_y


def is_wall(x, y):
    if x < 0 or x >= COLS or y < 0 or y >= ROWS:
        return True

    return maze[y][x] == "#"


def reset_game():
    pacman = {
        "x": tile_center(1),
        "y": tile_center(1),
        "direction": STOP,
        "next_direction": STOP,
        "facing": (1, 0),
    }

    ghosts = [
        {
            "x": tile_center(19),
            "y": tile_center(13),
            "direction": STOP,
            "color": RED,
        },
        {
            "x": tile_center(1),
            "y": tile_center(13),
            "direction": STOP,
            "color": PINK,
        },
        {
            "x": tile_center(19),
            "y": tile_center(1),
            "direction": STOP,
            "color": CYAN,
        },
    ]

    dots = set()

    for y in range(ROWS):
        for x in range(COLS):
            if maze[y][x] in (".", "o"):
                dots.add((x, y))

    return pacman, ghosts, dots


def can_move(actor, direction):
    """Is the tile next to the actor in this direction free?"""
    if direction == STOP:
        return True

    tile_x, tile_y = current_tile(actor["x"], actor["y"])
    dx, dy = direction

    return not is_wall(tile_x + dx, tile_y + dy)


def at_tile_center(actor):
    """True only when the actor is exactly on a tile center."""
    tile_x, tile_y = current_tile(actor["x"], actor["y"])

    return (
        abs(actor["x"] - tile_center(tile_x)) < EPS
        and abs(actor["y"] - tile_center(tile_y)) < EPS
    )


def snap_to_center(actor):
    tile_x, tile_y = current_tile(actor["x"], actor["y"])

    actor["x"] = tile_center(tile_x)
    actor["y"] = tile_center(tile_y)


def distance_to_next_center(actor):
    """Pixels from the actor to the next tile center in its direction."""
    dx, dy = actor["direction"]

    if dx != 0:
        p = (actor["x"] - TILE_SIZE / 2) / TILE_SIZE
        d = dx
    else:
        p = (actor["y"] - TILE_SIZE / 2) / TILE_SIZE
        d = dy

    if d > 0:
        n = math.floor(p + EPS) + 1
        return (n - p) * TILE_SIZE

    n = math.ceil(p - EPS) - 1
    return (p - n) * TILE_SIZE


def move_actor(actor, speed, choose_direction):
    """
    Move an actor `speed` pixels along its direction.

    The move is split at tile centers, so the actor always lands exactly
    on a center, where it may turn. It can never skip a turn or move into
    a wall, whatever the speed is.
    """
    remaining = speed

    while remaining > EPS:
        if at_tile_center(actor):
            snap_to_center(actor)
            choose_direction(actor)

            if actor["direction"] == STOP:
                return

        dx, dy = actor["direction"]

        if dx == 0 and dy == 0:
            return

        step = min(remaining, distance_to_next_center(actor))

        actor["x"] += dx * step
        actor["y"] += dy * step
        remaining -= step


def choose_pacman_direction(pacman):
    if can_move(pacman, pacman["next_direction"]):
        pacman["direction"] = pacman["next_direction"]

    elif not can_move(pacman, pacman["direction"]):
        pacman["direction"] = STOP


def choose_ghost_direction(ghost):
    options = [d for d in DIRECTION_LIST if can_move(ghost, d)]

    reverse = (-ghost["direction"][0], -ghost["direction"][1])
    forward = [d for d in options if d != reverse]

    if forward:
        options = forward

    ghost["direction"] = random.choice(options) if options else STOP


def move_pacman(pacman):
    current = pacman["direction"]
    wanted = pacman["next_direction"]

    # Reversing is allowed anywhere, not just at tile centers.
    if current != STOP and wanted == (-current[0], -current[1]):
        pacman["direction"] = wanted

    move_actor(pacman, PAC_SPEED, choose_pacman_direction)

    if pacman["direction"] != STOP:
        pacman["facing"] = pacman["direction"]


def move_ghosts(ghosts):
    for ghost in ghosts:
        move_actor(ghost, GHOST_SPEED, choose_ghost_direction)


def draw_maze(dots):
    for y in range(ROWS):
        for x in range(COLS):
            if maze[y][x] == "#":
                rect = pygame.Rect(
                    x * TILE_SIZE,
                    y * TILE_SIZE + TOP_SPACE,
                    TILE_SIZE,
                    TILE_SIZE,
                )

                pygame.draw.rect(screen, BLUE, rect)
                pygame.draw.rect(
                    screen,
                    BLACK,
                    rect.inflate(-5, -5),
                    border_radius=5,
                )

    for x, y in dots:
        center_x = int(tile_center(x))
        center_y = int(tile_center(y) + TOP_SPACE)

        radius = 6 if maze[y][x] == "o" else 3

        pygame.draw.circle(
            screen,
            WHITE,
            (center_x, center_y),
            radius,
        )


def draw_pacman(pacman):
    center_x = int(pacman["x"])
    center_y = int(pacman["y"] + TOP_SPACE)

    pygame.draw.circle(
        screen,
        YELLOW,
        (center_x, center_y),
        TILE_SIZE // 2 - 2,
    )

    # Animated mouth (keeps facing the last direction when stopped).
    dx, dy = pacman["facing"]

    angle = math.atan2(-dy, dx)
    radius = TILE_SIZE // 2 - 1

    if pacman["direction"] != STOP:
        mouth_angle = 0.1 + 0.4 * abs(math.sin(pygame.time.get_ticks() / 90))
    else:
        mouth_angle = 0.35

    point1 = (
        int(center_x + radius * math.cos(angle - mouth_angle)),
        int(center_y - radius * math.sin(angle - mouth_angle)),
    )

    point2 = (
        int(center_x + radius * math.cos(angle + mouth_angle)),
        int(center_y - radius * math.sin(angle + mouth_angle)),
    )

    pygame.draw.polygon(
        screen,
        BLACK,
        [(center_x, center_y), point1, point2],
    )


def draw_ghosts(ghosts):
    for ghost in ghosts:
        center_x = int(ghost["x"])
        center_y = int(ghost["y"] + TOP_SPACE)
        radius = TILE_SIZE // 2 - 2

        pygame.draw.circle(
            screen,
            ghost["color"],
            (center_x, center_y),
            radius,
        )

        pygame.draw.rect(
            screen,
            ghost["color"],
            (
                center_x - radius,
                center_y,
                radius * 2,
                radius - 1,
            ),
        )

        pygame.draw.circle(
            screen, WHITE, (center_x - 5, center_y - 3), 4
        )
        pygame.draw.circle(
            screen, WHITE, (center_x + 5, center_y - 3), 4
        )

        pygame.draw.circle(
            screen, BLACK, (center_x - 5, center_y - 3), 2
        )
        pygame.draw.circle(
            screen, BLACK, (center_x + 5, center_y - 3), 2
        )


def draw_message(message):
    text = big_font.render(message, True, YELLOW)

    screen.blit(
        text,
        (
            WIDTH // 2 - text.get_width() // 2,
            TOP_SPACE + ROWS * TILE_SIZE // 2
            - text.get_height() // 2,
        ),
    )


def update(pacman, ghosts, dots, score):
    """One frame of game logic. Returns (score, game_over, won)."""
    move_pacman(pacman)
    move_ghosts(ghosts)

    # Collect dots.
    pac_tile = current_tile(pacman["x"], pacman["y"])

    if pac_tile in dots:
        dots.remove(pac_tile)
        score += 10

    # Check collisions.
    game_over = False

    for ghost in ghosts:
        distance = math.hypot(
            pacman["x"] - ghost["x"],
            pacman["y"] - ghost["y"],
        )

        if distance < TILE_SIZE - 4:
            game_over = True
            break

    won = len(dots) == 0

    return score, game_over, won


async def main():
    pacman, ghosts, dots = reset_game()

    score = 0
    game_over = False
    won = False
    running = True

    while running:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_r:
                    pacman, ghosts, dots = reset_game()
                    score = 0
                    game_over = False
                    won = False

                elif event.key in DIRECTIONS:
                    # Buffered until Pac-Man reaches a tile where the
                    # turn is possible.
                    pacman["next_direction"] = DIRECTIONS[event.key]

        if not game_over and not won:
            score, game_over, won = update(pacman, ghosts, dots, score)

        # Draw the screen.
        screen.fill(BLACK)

        score_text = font.render("Score: " + str(score), True, WHITE)
        screen.blit(score_text, (10, 12))

        help_text = font.render(
            "Arrows/WASD: Move   R: Restart",
            True,
            WHITE,
        )
        screen.blit(help_text, (190, 12))

        draw_maze(dots)
        draw_pacman(pacman)
        draw_ghosts(ghosts)

        if game_over:
            draw_message("GAME OVER! Press R")
        elif won:
            draw_message("YOU WIN! Press R")

        pygame.display.flip()

        # Required for the browser version: lets the page breathe each
        # frame. Harmless when running on the desktop.
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
